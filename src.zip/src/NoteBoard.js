import React, { useState, useEffect } from 'react';
import Node from './Node';
import NoteForm from './noteForm';

const NoteBoard = () => {
  const [notes, setNotes] = useState(() => {
    // Recuperar notas desde el almacenamiento local cuando el componente se monta
    const savedNotes = localStorage.getItem('notes');
    return savedNotes ? JSON.parse(savedNotes) : [];
  });

  // Guardar notas en el almacenamiento local cuando cambian las notas
  useEffect(() => {
    localStorage.setItem('notes', JSON.stringify(notes));
  }, [notes]);

  const addNote = (note) => {
    setNotes([...notes, note]);
  };

  return (
    <div className="note-board">
      <NoteForm addNote={addNote} />
      <div className="notes">
        {notes.map((note, index) => (
          <Node key={index} note={note} />
        ))}
      </div>
    </div>
  );
};

export default NoteBoard;
