

import React from 'react';

const Node = ({ note }) => {
  const noteClass = note.important ? 'note important' : 'note';

  return (
    <div className={noteClass} style={{ transform: `rotate(${note.rotation}deg)` }}>
      <h3>{note.title}</h3>
      <p>{note.description}</p>
    </div>
  );
};

export default Node;
